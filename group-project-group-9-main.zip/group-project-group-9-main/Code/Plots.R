# calling the library

library(ggplot2)

countries = as.factor(chart$area_vec)
countries <- levels(countries)

freq <- chart%>%group_by(area_vec)%>%summarise(no_rows = length(area_vec))
freq <- data.frame(freq)


# making the pie chart of countries wise distribution of different category

ggplot(freq,aes(x = "", y = no_rows,fill = area_vec))+
       geom_bar(stat = "identity", width = 1, color = "white")+
       coord_polar("y",start = 0)+ 
       theme_void()+
       ggtitle("Regions(Countries)")

freq_lang <- chart%>%group_by(lang)%>%summarise(no. = length(lang))
freq_lang <- data.frame(freq_lang)


# making the pie chart of different languages

ggplot(freq_lang,aes(x = "",y = no.,fill = lang))+
      geom_bar(stat = "identity",width = 1, color = "white")+
      coord_polar("y",start = 0)+
      theme_void()+
      ggtitle("Proportion of Languages")


# plotting the histogram of Noxscore values of channels

ggplot(chart, aes(x= NoxScore))+
      geom_histogram(color = "blue",fill = "lightblue")+
      ggtitle("Histogram of Noxscore values of channels")


# Here Noxscore is fitted with a Normal distribution curve

ggplot(chart, aes(x= NoxScore))+
      geom_histogram(aes(y = ..density..),color = "blue",fill = "lightblue")+
      stat_function(fun = dnorm, args = list(mean = mean(chart$NoxScore),sd = sd(chart$NoxScore)),col = "black",size = 3)+
      ggtitle("Noxscore fitted with a Normal distribution curve")

categ <- data.frame(chart$category)
freq_categ <- categ%>%group_by(category)%>%summarise(Frequency = length(category))

freq_categ <-data.frame(freq_categ)


# making a pie chart of different category

ggplot(freq_categ,aes(x= "",y = Frequency,fill = chart$category))+
      geom_bar(stat = "identity",width = 1,color = "white")+
      coord_polar("y",start = 0)+ 
      theme_void()+
      ggtitle("Category")

# plotting a scatter plot of Subscribers vs Total Videos to see their correlation

ggplot(chart,aes(x = total_videos,y = subscribers*1e6, col = category))+
       geom_point()+labs(y = "subscribers", x = "Total Videos")+
       ggtitle("Subscribers vs Total Videos")


# plotting a scatter plot of Subscribers vs Total Views to see their correlation

ggplot(chart,aes(x = totalviews,y = subscribers*1e6,col = lang))+ 
      geom_point()+labs(x= "Total Views", y = "Subscribers")+
      ggtitle("Subscribers vs Total Views")


# plotting a boxplot of Category vs Totalviews

ggplot(chart, aes(x = category, y = totalviews))+
      geom_boxplot()+coord_flip()+
      labs(title = "Category vs Totalviews")


# plotting a bar Plot of Category vs Subscribers

ggplot(chart, aes(x = category, y = subscribers*1e6)) + 
      geom_bar(stat = "identity", fill = "steelblue")+ 
      coord_flip()+
      ggtitle("Bar Plot of Category vs Subscribers")


# Histogram showing the number of years it took to reach a certain number of subscribers

ggplot(chart, aes(x = time_difference)) + 
      geom_histogram(binwidth = 1,col = "blue", fill = "light blue") + 
      labs(x = "Time Difference", ylab = "Count") + 
      ggtitle("Histogram showing the number of years it took to reach a certain number of subscribers")


# plotting a boxplot of Category vs Total videos
ggplot(chart, aes(x = category, y = total_videos, fill = lang))+
       geom_boxplot()+stat_summary(fun = "mean", geom = "point")+
       coord_flip()+
       labs(title = "Project Plot", subtitle = "Boxplot of Category vs Total videos")+
       xlab("Category")+
       ylab("Total Vedios")
