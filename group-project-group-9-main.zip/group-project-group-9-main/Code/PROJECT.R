# calling the libraries

library(rvest)
library(tidyverse)
library(stringi)
library(imager)
library(magrittr)

# url of our dataset

html <- read_html("https://www.noxinfluencer.com/youtube-channel-rank/top-100-all-all-youtuber-sorted-by-subs-weekly")


# Name of the youtube channels 

channel_name <- html %>% html_elements(".title.pull-left.ellipsis")%>% html_text()




# Youtube channel category

category <- html %>% html_elements(".category")%>% html_text()
category <- append(category,values = "News & Politics",after = 81) # missing category 




sub <- html %>% html_elements(".number")%>% html_text() 


# Number of subscribers

func <- function()
{
  subs <- vector(length=100)
  for(i in 1:100)
  {
    subs[i] <- sub[3*i-1]
  }
  return(subs)
}
subscribers <- func()
subscribers <- as.numeric(str_sub(subscribers,0,-2)) # in million
subscribers <- subscribers * 1e6

# Average Views

func1 <- function()
{
  vie <- vector(length=100)
  for(i in 1:100)
  {
    vie[i] <- sub[3*i]
  }
  return(vie)
}
avg_views <- func1()

lastletter <- str_sub(avg_views,-1)
first <- as.numeric(str_sub(avg_views,1,-2))


full_avg_views <- function()
{
  full <- vector(length = 100)
  for (i in 1:100)
  {
    if (lastletter[i] == "M")
    {
      full[i] <- first[i]*1000000
    }
    else{full[i] <- first[i]*1000}
  }
  return(full)
}
avg.views <- full_avg_views() # here we get accurate average views


# now it is time to go in the urls of every channel

url <- html %>% html_elements(".link.clearfix")%>% html_attr("href")
urls <- paste("https://www.noxinfluencer.com", url, sep = "")


# Extracting Noxscore

nox <- function()
{
  NoxScore <- vector(length=100)
  for(i in 1:100)
  {
    link <- read_html(urls[i])
    NoxScore[i] <- link %>% html_elements(".noxscore-content")%>% html_text()
  }
  return(NoxScore)
}
Noxscore <- nox()
NoxScore <- as.numeric(str_sub(Noxscore,4,-19)) # noxscore data


# Extracting Total Views

totalviews <- function()
{
  total <- vector(length=100)
  new_total <- vector(length=100)
  
  for(i in 1:100)
  {
    link <- read_html(urls[i])
    views <- link %>% html_elements(".value-content")%>% html_text()
    total[i] <- views[2]
    total[i] <- gsub(" ","",total[i])#removing extra spaces from the total[i] element
    finals <- str_sub(total[i],1,7)#extracting first 7 digits and storing in finals(as ther can be maximum 7 digits of our use)
    character <- stri_sub(finals,-1)#extracting last digit of finals
    if(!(character=="0"||character=="1"||character=="2"||character=="3"||character=="4"||character=="5"||character=="6"||character=="7"||character=="8"||character=="9"||character=="M"||character=="B"))
    {
      finals <- gsub(character,"",finals)#if the last character of finals is not a digit or "M" or"B" then simply remove the last character
    }
   
    n <- nchar(finals)#calculate new number of characters(6 or 7 accordingly)
    num <- str_sub(finals,1,n-1)#extract first n-1 numeric characters
    num <- as.numeric(num)
    c <- stri_sub(finals,-1)#extract last charcater to check for "M" or "B"
    if(c=="M")
    {
      new_total[i] = num*1000000
    }
    if(c=="B")
    {
      new_total[i] = num*1000000000
    
    }
    
  }
  
  return(new_total)
}
totalviews <- totalviews()


# Extracting total number of videos

total <- list(100)

for(i in 1:100)
{
  chanel_html <- read_html(urls[i])
  total[[i]] <- chanel_html %>% html_elements(".strong") %>% html_text()
}
total_videos <- numeric(100)


for(i in 1:100)
{
  total_videos[i] <- total[[i]][[4]]
  
}


last <- str_sub(str_sub(total_videos,-2),-2)


total.video <- function()
{
  tot <- vector(length=100)
  for (i in 1:100) 
  {
    if(last[i] == "K ")
    {
      first <- str_sub(total_videos[i],2,-3)
      tot[i] <- as.numeric(first) * 1000
    }
    else 
    {
      tot[i]<- str_sub(total_videos[i],2,-2)
    }
    
  }
  return(as.numeric(tot))
}
total_videos <- total.video() 

# Extracting area channels are most subscribed in

 area <- function()
  {
    area_vec1 <- vector(length = 100)
    for(i in 1:100)
    {
      lang_url <- read_html(urls[i])
      info <- lang_url %>% html_elements(".pull-right.item-value") %>% html_text()
      area_vec1[i] <- info[2]
    }
    return(area_vec1)
  }
    area_vec <- area()
  
 # Extracting language    
  
 language <- function()
  {
     lang1 <- vector(length = 100)
      for(i in 1:100)
      {
       
        lang_url <- read_html(urls[i])
        info <- lang_url %>% html_elements(".pull-right.item-value") %>% html_text()
        lang1[i] <- info[3]
      }
     return(lang1)
  }
lang <- language()

# Extracting Year a channel joined Youtube
date_joined <- function()
{
  date1 <- vector(length = 100)
  for(i in 1:100)
  {
    
    date_url <- read_html(urls[i])
    info <- date_url %>% html_elements(".pull-right.item-value") %>% html_text()
    date1[i] <- info[1]
  }
  return(date1)
}
date <- date_joined()
date <- as.integer(substring(date, 1, 5 ))


# save this data in a data frame so that all codes are not run again and again
chart <- data.frame(channel_name, category, subscribers, avg.views, NoxScore, totalviews, total_videos ,area_vec, lang, date)
view(chart) 
time_diff <- 2022 - chart$date
chart$time_difference <- time_diff
save(chart, file = "Final_DataFrame.Rdata")




