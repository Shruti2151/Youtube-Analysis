          Analysis of Top 100 Most Subscribed Youtubers in the World
                - By group 9 under the guidance of Dr. Dootika Vats.
                
 Here we have worked on the top 100 most subscribed youtubers. So, we have extracted out data from https://www.noxinfluencer.com/youtube-channel-rank/top-100-all-all-youtuber-sorted-by-subs-weekly through R studio using rvest, tidyverse libraries. Our data consists 100 observations both quantitative and qualitative. We have faced some challenges to work with this data such that missing data, conversion of data type, connection timed out.

 Then we have found some interesting questions that is mentioned in the report and we have tried to answer those questions through different plots like histogram, pie chart, bar plot, box plot, frequency line, scatter plot. In the report conclusions that we can make from our diagrams are written under every plot.

 Next, our shiny app comes that is interactive. Using the shiny app, observing the behaviors of the plots we have tried to understand what our data is saying, how number of subscribers are related with different aspects, how the content is distributed among top 100 most subscribed youtubers.

 Finally, we have come to our overall conclusions. On an average number of subscribers are positively correlated with NoxSCore and total views but there are many exceptions (possible reasons are discussed in the report). 
 
 NOTE : While loading the .rmd report file, please ensure that the dataframe object is present in the working directory and use the entire file path of the object while loading the dataframe object.

 Thank you,



